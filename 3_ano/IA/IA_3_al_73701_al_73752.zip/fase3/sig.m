function [s]=sig(x)
    s=1./(1+exp(-x));
end